---
navigation_title: 'Release notes'
mapped_pages:
  - https://www.elastic.co/guide/en/ecs/current/ecs-release-notes.html
---

# ECS release notes [ecs-release-notes]

This section summarizes the changes in each release.





















