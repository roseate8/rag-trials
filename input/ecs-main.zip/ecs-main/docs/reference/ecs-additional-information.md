---
mapped_pages:
  - https://www.elastic.co/guide/en/ecs/current/ecs-additional-information.html
applies_to:
  stack: all
  serverless: all
navigation_title: Additional information
---

# Additional ECS information [ecs-additional-information]

* [Questions and Answers](/reference/ecs-faq.md)
* [Contributing to ECS](/reference/ecs-contributing.md)
* [Generated Artifacts](/reference/ecs-artifacts.md)





